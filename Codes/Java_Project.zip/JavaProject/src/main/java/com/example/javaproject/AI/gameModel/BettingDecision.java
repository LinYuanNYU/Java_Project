package com.example.javaproject.AI.gameModel;

public enum BettingDecision {
    CALL, FOLD, RAISE
}
